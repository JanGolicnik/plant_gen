# Lsystem showcase

Made a simple thing to showcase my improved rendering engine, everything is so simple now :)

LSystems are really cool tho and I wanted to implement one myself since forever
I'll be adding WASM support to the engine soon so I'll made it editable trough a textbox and it'll be a fun app to play around with

I basically just copied [this](https://www.youtube.com/watch?v=1hcCpLQwI-c) video
