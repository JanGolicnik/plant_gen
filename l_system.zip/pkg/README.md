# Lsystem showcase

Made a simple thing to showcase my improved rendering engine, everything is so simple now :)

LSystems are really cool tho and I wanted to implement one myself since forever

Try it live [here](https://janyg.itch.io/lsystem-editor)

Main inspiration was [this](https://www.youtube.com/watch?v=1hcCpLQwI-c) video
